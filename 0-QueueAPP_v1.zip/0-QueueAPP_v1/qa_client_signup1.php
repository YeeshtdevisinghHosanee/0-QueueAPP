<?php
require_once 'qa_connection.php';
$g_username=$_POST['username'];
$g_password=$_POST['password'];
$g_fname=$_POST['fname'];
$g_lname=$_POST['lname'];

//echo '</br>var1'.$g_username;



$db="tbl_client";
 $client = new couchClient($url,$db);
  $all_singers = $client->getAllDocs();
  foreach ( $all_singers->rows as $row ) {
   
    $doc = CouchDocument::getInstance($client,$row->id);
	
	$user_id=$doc->_id;
	$user_name=$doc->username;

  
	//echo "<br/>".$user_id;
	//echo "<br/>".$user_name;
	//echo "<br/>".$user_password;
	//echo "<br/>".$user_branch;
	
	if ($user_name==$g_username)
	{
		
		
		
			$g_check=9;
		
		
	}	
	
	
   }




 
 if ($g_check==9)
 {
	echo "Username already exists.";
 }

else
{
				$current_cid=0;
				$g_cid=0;
				
				$client = new couchClient($url,$db);
				
				$all_records = $client->getAllDocs();
				//echo '<select size="1" style="width:400px" width="10" name="txt_bname" id="txt_bname">';
				
				foreach ( $all_records->rows as $row ) {
				   
					$doc = CouchDocument::getInstance($client,$row->id);
					//print_r ($doc);
					$user_bid=$doc->id;
					if ($user_bid>$g_cid)
					{
						$g_cid=$user_bid;
					}
					echo "<br/>".$user_bid;

				 }
				 $current_cid=$g_cid+1;
				 $dt=date("Y-m-d H:i:s");
				 	$prop = new stdClass();
					$prop->_id = "".$current_cid."";
					$prop->id = $current_cid;
					$prop->username = $g_username;
					$prop->password = $g_password;
					$prop->fname = $g_fname;
					$prop->lname = $g_lname;
					$prop->date_created = $dt;

					$doc = new CouchDocument($client);
					if ($doc->set ( $prop ))
					{
						header("location:index.html");
						
						
					}
					else
					{
						echo "A problem occured.The system could not insert record in database";
						
					}	
	
	
	
	
}


?>
