<?php
require_once 'qa_connection.php';
session_start() ;

 $docid=$_SESSION['docid'] ;
	$user=  $_SESSION['username'] ;
	 $fname=  $_SESSION['fname'] ;
	 echo '<font size="3" color="blue" ><p align="right"><a href="qa_client_login.php">Sign out</a></p></font></br>';


	 echo  '<font size="3" color="black">'."Hello, ". $fname."</font> ";
	  echo  '</br></br></br>';
//echo '<font size="5" color="black">Booking:</br></br><a href="qa_client_sversion.php" >1.Drop Down View</a>    </br>          <a href="qa_client_dversion.php">2.Grid View</a></font>';
echo '<font size="5" color="black"></br></br><a href="qa_client_dversion.php">Grid View booking</a></font>';


echo  '</br>';
echo  '</br>';

	$_SESSION['clientid'] = $docid;
	 $_SESSION['username']=$user ;
	   $_SESSION['fname'] = $fname;
	 
?>

