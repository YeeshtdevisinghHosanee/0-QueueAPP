<?php
require_once 'qa_connection.php';
$dt=date("Y-m-d H:i:s");
$g_uid=$_GET['uid'];
$g_bid=$_GET['bid'];
$g_docid=$_GET['docid'];

echo "User:".$g_uid."   BranchID:".$g_bid;
$filepath="qa_admin_montickets.php?uid=".$g_uid."&bid=".$g_bid."&docid=".$g_docid;
$check=0;
$selected_val=0;

$db="tbl_clientlog";
if(isset($_POST['clicked'])){
	$selected_val = key($_POST['clicked']); 
$arra1=explode('-',$selected_val);
$check=1;
if ($check=1)
{
	//$col1=$_POST['col1_'.$selected_val];
	//$col2=$_POST['col2_'.$arra1[0].'-'.$arra1[1]];
	//$col3=$_POST['col3_'.$arra1[0].'-'.$arra1[1]];
	//$col4=$_POST['col4_'.$arra1[0].'-'.$arra1[1]];
	//$col5=$_POST['col5_'.$arra1[0].'-'.$arra1[1]];
	//$col6=$_POST['col6_'.$arra1[0].'-'.$arra1[1]];
	$col7=$_POST['col7_'.$arra1[0].'-'.$arra1[1]];
	//$col8=$_POST['col8_'.$arra1[0].'-'.$arra1[1]];
	//$col9=$_POST['col9_'.$arra1[0].'-'.$arra1[1]];
	$col10=$_POST['col10_'.$arra1[0].'-'.$arra1[1]];
	$doc1=$_POST['doc_'.$arra1[0].'-'.$arra1[2]];
	
	
	
	/**
		echo "</br>".$doc1;
		//echo "</br>first1".$add1;
			echo "</br>first12".$col2;
				echo "</br>first13".$col3;
					echo "</br>first12".$col4;
				echo "</br>first13".$col5;
					echo "</br>first12".$col6;
				echo "</br>first13".$col8;
				//	echo "</br>first12".$add10;
				//echo "</br>first13".$add3;
	
	**/
	
	
	
	
	
	
	
	
	
	
	$client3 = new couchClient($url,$db);
	$doca = $client3->getDoc($doc1);
							// updating document
							//$doca->fname = $col2;
							//$doca->lname = $col3;
							
							
							//$doca->_id = "".$current_cid."";
					//$prop->id = $current_cid;
					
					//$doca->_id = "".$current_cid."";
			//$doca->id = $current_cid;
			
			$doca->status = $col7;
			
			$doca->date_modified = $dt;
			$doca->modified_by = $col10;
					
					
					
					
							
							try {
							   $client3->storeDoc($doca);
							    header("location:".$filepath);
							} catch (Exception $e) {
							   echo "Document storage failed : ".$e->getMessage()."<BR>\n";
							}
	
	
	
	
}

}


if(isset($_POST['clicked1'])){ //delete
	$selected_val = key($_POST['clicked1']); 

$check=1;
if ($check=1)
{
	//$col1=$_POST['col1_'.$selected_val];
	//$col2=$_POST['col2_'.$selected_val];
	//$col3=$_POST['col3_'.$selected_val];
	$doc1=$_POST['doc_'.$selected_val];
	$client = new couchClient($url,$db);
	$doc = $client->getDoc($doc1);
	try {
   $client->deleteDoc($doc);
   header("location:".$filepath);
	} 
	catch (Exception $e) {
	echo "Document storage failed : ".$e->getMessage()."<BR>\n";
	}
		 
	
}
}

if(isset($_POST['clicked2'])){
	$add = key($_POST['clicked2']); 
	//$add1=$_POST['add1_'.$add];
	
	$add3=$_POST['add3_'.$add];
	$add4=$_POST['add4_'.$add];
	$add5=$_POST['add5_'.$add];
	$add6=$_POST['add6_'.$add];
	$add7=$_POST['add7_'.$add];
	//dd8=$_POST['add8_'.$add];
	$add9=$_POST['add9_'.$add];
	//dd10_POST['add10.$add];
	
	echo "</br>".$add;
		//echo "</br>first1".$add1;
			echo "</br>first12".$add3;
				echo "</br>first13".$add4;
					echo "</br>first12".$add5;
				echo "</br>first13".$add6;
					echo "</br>first12".$add7;
				echo "</br>first13".$add9;
				//	echo "</br>first12".$add10;
				//echo "</br>first13".$add3;

	$check=45;
	
	
	
	
				$current_cid=0;
				$g_cid=0;
				
				$client = new couchClient($url,$db);
				
				$all_records = $client->getAllDocs();
				//echo '<select size="1" style="width:400px" width="10" name="txt_bname" id="txt_bname">';
				
				foreach ( $all_records->rows as $row ) {
				   
					$doc = CouchDocument::getInstance($client,$row->id);
					//print_r ($doc);
					$user_bid=$doc->id;
					if ($user_bid>$g_cid)
					{
						$g_cid=$user_bid;
					}
					echo "<br/>".$user_bid;

				 }
				 $current_cid=$g_cid+1;
				 
				 	//$prop = new stdClass();
					//$prop->_id = "".$current_cid."";
					//$prop->id = $current_cid;
					//$prop->fname = $add2;
					//$prop->lname = $add3;
					$dt=date("Y-m-d h:i:s");
					$prop = new stdClass();
					$prop->_id = "".$current_cid."";
					$prop->id = $current_cid;
					$prop->branchid = $add3;
					$prop->bcnum = $add4;
					$prop->maxserved = $add5;
					$prop->start_time = $add6;
					$prop->end_time = $add7;
					$prop->current_time = $add6;
					$prop->counter = $add9;
					$prop->date_created = $dt;
				


					$doc = new CouchDocument($client);
					if ($doc->set ( $prop ))
					{
						
						mkdir($current_cid, 777, true);
						echo "Insertion completed successfully";
						
						header("location:".$filepath);
					}
					else
					{
						echo "could not insert record in database";
						
					}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}




?>


<head>
<title>Test this</title>
</head>
<body>



</body>
</html>