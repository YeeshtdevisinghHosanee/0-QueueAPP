
<?php
require_once 'qa_connection.php';
////date_default_timezone_set('Asia/Dubai');

echo '<font size="2" color="blue" ><p align="right"><a href="qa_client_dversion.php">Back</a></p></font></br>';

session_start() ;

	$clientid=$_SESSION['clientid'] ;
	$user=  $_SESSION['username'] ;
	$fname=  $_SESSION['fname'] ;
	 
	// echo $clientid."Hello ". $fname;


//echo "clicked on".key($_POST['clicked']);

echo '<html><body style="background-color:#E6E6FA" >';
//if(isset($_POST['submit']))
//{
	ini_set('max_execution_time', 300); //300 seconds = 5 minutes
	set_time_limit(300);
	
	
	
	
		$checka=0;
			
				$db22="tbl_clientlog";
				
				$client22 = new couchClient($url,$db22);
				
				$all_records22 = $client22->getAllDocs();
				//echo '<select size="1" style="width:400px" width="10" name="txt_bname" id="txt_bname">';
				
				foreach ( $all_records22->rows as $row22 ) {
				   
					$doc22 = CouchDocument::getInstance($client22,$row22->id);
					//print_r ($doc);
					$clid=$doc22->clientid;
					$ctime=$doc22->time_assisted;
					if ($clid==$clientid)
					{
						
						$newtime =date("Ymd", strtotime($ctime));
						$todayd=date("Ymd");
					//echo "</br>username".$newtime;
						//echo "</br>today".$todayd;
						if ($newtime==$todayd)
						{
							$checka=2;
							//echo "</br>check".$checka;
						echo "You already have a booking on ".date("d-m-Y H:i:s", strtotime($ctime));
						}
							
					}
					

				 }
	
	
	
	
	
	
	if ($checka==0)
	{
	
	
	$selected_val = key($_POST['clicked']);  // Storing Selected Value In Variable

$retrievedval=$selected_val;
	//echo "yes1".$selected_val;
	$array_opt=explode(";",$selected_val);  // split from selected option html [0]- current_criteria id, [1]-  ending time, [2]-  current time, [3]-  current time
	//echo "yes".$array_opt[2]; 
	
	//$date1 =date("Y-m-d H:i:s", strtotime($ectime)+($emax_served*60));
	
	//$date1 =date("Ymd H:i:s", strtotime($array_opt[1]));
	//$date2=date("m/d h:i:s");
	$idretrieve=$array_opt[0];
	$eetime=$array_opt[1];
	$ectime=$array_opt[2];
	$emax_served=$array_opt[3];
	$ecounter=$array_opt[4];
	$ebid=$array_opt[5];
	$ebranchname=$array_opt[6];
	
	$endingdate =date("Ymd", strtotime($array_opt[1]));
	$todaydate=date("Ymd");
	//echo "</br>endingdate".$endingdate ;
	//echo "</br>todaydate".$todaydate ;
	//echo "</br>id".$idretrieve ;
	//echo "</br>endtime".$eetime ;
	//echo "</br>ctime".$ectime ;
	//echo "</br>max served".$emax_served ;
	
	
	$newtime_f =date("YmdHis", strtotime($ectime)+($emax_served*60));
	$newtime_f1 =date("d-m-Y H:i:s", strtotime($ectime)+($emax_served*60));
	$endtim_f =date("YmdHis", strtotime($eetime));
	
	
	//echo "</br>proposed new".$newtime_f ;
	//echo "</br>endtief".$endtim_f ;
	
	if ($endingdate==$todaydate)  // verify if selection is today's date
	{
		//echo "Selection of date ok.";
		if ($newtime_f>$endtim_f) //new time should not be greater than ending time
		{
			echo "We are sorry.This counter is fully booked. Try another one.";
			
		}	
		else
		{
		
		


				$current_cid=0;
				$g_cid=0;
				$db2="tbl_clientlog";
				
				$client2 = new couchClient($url,$db2);
				
				$all_records2 = $client2->getAllDocs();
				//echo '<select size="1" style="width:400px" width="10" name="txt_bname" id="txt_bname">';
				
				foreach ( $all_records2->rows as $row2 ) {
				   
					$doc2 = CouchDocument::getInstance($client2,$row2->id);
					//print_r ($doc);
					$user_bid=$doc2->id;
					if ($user_bid>$g_cid)
					{
						$g_cid=$user_bid;
					}
					//echo "<br/>".$user_bid;

				 }
				 $current_cid=$g_cid+1;
				 

//echo "</br>current id----?".$current_cid ;
$dt=date("Y-m-d H:i:s");

			$prop = new stdClass();
			$prop->_id = "".$current_cid."";
			$prop->id = $current_cid;
			$prop->currentcounter = $ecounter;
			$prop->time_assisted = $newtime_f1;
			$prop->branchid = $ebid;
			$prop->branch_name = $ebranchname;
			$prop->path = "";
			$prop->status = "InProgressed";
			$prop->date_created = $dt;
			$prop->date_modified = "";
			$prop->modified_by = "";
			$prop->ticketnumber = $idretrieve."A".$current_cid;
			$prop->clientid = $clientid;

			$db2="tbl_clientlog";
			$client2 = new couchClient($url,$db2);
			$doc2 = new CouchDocument($client2);
			if ($doc2->set ( $prop ))
			{
				
				
				//echo "Insertion into clientlog completed successfully.";
								
				$g_val1="";
				$g_val2="";
				$g_val3="";
				$g_val4="";
				$g_val5="";
				$g_val6="";
				$g_val7="";
				
				//print_r ($doc2);
				
				
				//$db3="tbl_counter_criteria";
				//$client3 = new couchClient($url,$db3);
				//$doc3 = CouchDocument::getInstance($client3,$row->id);
				
				
				
				

				$g_check=0;
				$db3="tbl_counter_criteria";
				$client3 = new couchClient($url,$db3);
				$all_records3 = $client3->getAllDocs();
				 foreach ( $all_records3->rows as $row3 ) {
				   
					$doc3 = CouchDocument::getInstance($client3,$row3->id);
					
					$user_bid=$doc3->_id;
					$start_time1=$doc3->start_time;
					

					//echo "true<br/>".$user_bid;
					//echo "true2<br/>".$start_time1;
					//echo "<br/>".$user_bid;
							//echo "</br>i am in";
							//print_r ($doc3->_id);
							//echo "</br>i am out";
							//echo "bid1".$user_bid."bid2".$idretrieve;
							
							/**
							echo "</br>i am in";
							print_r ($doc3->_id);
							echo "</br>i am out"; **/
					
					if ($user_bid==$idretrieve)
					{
						
						
							//echo "</br>i am in";
							//print_r ($doc3->_id);
							//echo "</br>i am out";
							$g_check=9;
							$g_val1=$user_bid;
							
						    //$doc3->current_time=$newtime_f1;
							//$doc->current_time = array($newtime_f);
							//try {
							//$client3->storeDoc($doc3);
							//} catch (Exception $e) {
								//	echo "Document storage failed : ".$e->getMessage()."<BR>\n";
							//}
							
							$doca = $client3->getDoc($doc3->_id);
							// updating document
							$doca->current_time = $newtime_f1;
							try {
							   $client3->storeDoc($doca);
							} catch (Exception $e) {
							   echo "Document storage failed : ".$e->getMessage()."<BR>\n";
							}
				
						
						
					}	
					
					
				   }




				 
				 if ($g_check==9)
				 {
					// header("Location: qa_mainmenu.php?uid=".$g_uid."&bid=".$g_bid."&docid=".$g_docid);
					// echo "<br/>BranchName:".$g_val1;
					 
					 
					 
					 $filepath="./".$g_val1."/ticket".$g_val1."A".$current_cid.".html";
					
						//echo $filepath;
						if(!is_file($filepath)){
							//$txt_time='<font size="100px" color="blue"><center>'.$newtime_f1.'>>> Counter '.$ecounter.'</center></font>';
							//$txt_id='<font size="60px" color="blue"><center>ID:'.$g_val1.'A'.$current_cid.'</center></font>';
							 //$txt_1='<font size="10px" color="blue"><center>'.$ecounter.'</center></font>';
							 //$txt_bankname='<font size="20px" color="blue"><center>'.$ebranchname.'</center></font>';
							
							$txt_time='<h1 style="font-size:180px"><center>'.$newtime_f1.'</br>';
							
							$txt_id='<a>'.$g_val1.'A'.$current_cid.'-'.$clientid.'    Counter '.$ecounter.'</a>';
							//$txt_bankname='<h2 style="font-size:120px">'.$g_val1.'A'.$current_cid.'-'.$clientid.'@'.$ebranchname.'</h2>';
						     $txtuser='<h2 style="font-size:120px">'.$user.'@'.$ebranchname.'</h2></center></h1>';
							
							//$txt_all=$txt_time.$txt_id.$txtuser;
														$txt_all=$txt_time.$txt_id.$txtuser;
									$contents = '<html><body style="background-color:#E6E6FA">'.$txt_all.'</body></html>';           // Some simple example content.
								//file_put_contents($filepath, $contents);     // Save our content to the file.
								
								
								
						
						if (file_put_contents($filepath, $contents))
						{
								$filepath1=$g_val1."%2Fticket".$g_val1."A".$current_cid.".html";
								echo '<p style="font-size :30px; width: 100%; height: 100px;"><a href="qa_download.php?file=' . $filepath1 . '">'.'Download Ticket Here'.'</a></p>';
							
							
	
							
							
						}	
						}
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					
					 
				 }

				else
				{
					
					echo "A technical error occured. Try again.";
				}
								
								
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
			}
			else
			{
				echo "could not insert record into clientlog.";
				
			}	
			
		}	
		
	}
	else
	{
		echo "The selected date should be today's date.";
	}	
	
	
//}
	echo '</body ></html>';
}			
?>