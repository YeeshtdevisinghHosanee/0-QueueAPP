<?php
require_once 'qa_connection.php';


if(isset($_POST['submit'])){
$g_uid=$_POST['txt_id'];
$g_password=$_POST['txt_bname'];
$g_check=0;
$g_check2=0;
$g_bid=0;
$g_docid="";

////date_default_timezone_set('Asia/Dubai');
$date = date("Y/m/d");
$dt=date("Y/m/d h:i:s");

$temp="";
$bname="";
$result="";

$db="tbl_login";
 $client = new couchClient($url,$db);
  $all_singers = $client->getAllDocs();
  foreach ( $all_singers->rows as $row ) {
   
    $doc = CouchDocument::getInstance($client,$row->id);
	
	$user_id=$doc->_id;
	$user_name=$doc->username;
	$user_password=$doc->password;
	$user_branch=$doc->branchid;
  
	//echo "<br/>".$user_id;
	//echo "<br/>".$user_name;
	//echo "<br/>".$user_password;
	//echo "<br/>".$user_branch;
	$g_check2=3;
	if ($user_name==$g_uid)
	{
		//echo "yes";
		
		if ($user_password==$g_password)
		{
			$g_check=9;
			$g_bid=$user_branch;
			$g_docid=$user_id;
		}
		
		
	}	
	
	
   }




 
 if ($g_check==9)
 {
	 header("Location: qa_mainmenu.php?uid=".$g_uid."&bid=".$g_bid."&docid=".$g_docid);
	 
	 
 }

else
{
	
	
	//echo "Username/Password not correct.";
	
	
	if ($g_check2==0)
	{
		
		//echo "Username/Password not correct.";
	
					$g_uid="admin";
						$g_bid="1";
						$g_docid="1";
	
					$prop = new stdClass();
					$prop->_id = $g_docid;
					$prop->id =1;
					$prop->username = $g_uid;
					$prop->password = $g_uid;
					$prop->branchid = $g_bid;
					$prop->fname = "firstuser";
					$prop->lname =  "firstuser";
				
					$doc = new CouchDocument($client);
					if ($doc->set ( $prop ))
					{
						
						header("Location: qa_mainmenu.php?uid=".$g_uid."&bid=".$g_bid."&docid=".$g_docid);
						
						
					}
					else
					{
						echo "A problem occured.The system could not insert record in database";
						
					}	
		
	}
else
{

echo "Username/Password not correct.";

}	
	
	
	
}












}






//$conn->close();

//}
?>

<html>
 <form method="POST">
<font size="20" color="blue"><center><a>Admin Login Page</a></center></font></br>
	<table>
	
	
		<tr>
				<td>ID</td>
				<td><input style="width:200px" "type="text" id="txt_id" name="txt_id"       /></td>
		
		</tr>
		<tr>
				<td>Password</td>
				<td><input  style="width:200px"       type="password" id="txt_bname" name="txt_bname"      /></td>
		
		</tr>
		
		
		
	
	
		<tr>
				<td><input type="submit"  id="submit" name="submit"   onclick="func_a()"/></td>
		
		</tr>
	
	</table>




</form>

<div id="div_response" style="display:inline">

</div>



</html>