<?php
require_once 'qa_connection.php';
session_start() ;

if(isset($_POST['submit'])){
$g_uid=$_POST['txt_id'];
$g_password=$_POST['txt_bname'];
$g_check=0;
$g_bid=0;
$g_docid="";

////date_default_timezone_set('Asia/Dubai');
$date = date("Y/m/d");
$dt=date("Y/m/d h:i:s");

$temp="";
$bname="";
$result="";
	 echo '<font size="2" color="blue" ><p align="right"><a href="index.html">Back</a></p></font></br>';


$db="tbl_client";
 $client = new couchClient($url,$db);
  $all_singers = $client->getAllDocs();
  foreach ( $all_singers->rows as $row ) {
   
    $doc = CouchDocument::getInstance($client,$row->id);
	
	$user_id=$doc->id;
	$user_name=$doc->username;
	$user_password=$doc->password;
	$fname=$doc->fname;
	$lname=$doc->lname;
  
	//echo "<br/>".$user_id;
	//echo "<br/>".$user_name;
	//echo "<br/>".$user_password;
	//echo "<br/>".$user_branch;
	
	if ($user_name==$g_uid)
	{
		
		
		if ($user_password==$g_password)
		{
			$g_check=9;
			$g_bid=$fname." ".$lname;
			$g_docid=$user_id;
		}
		
		
	}	
	
	
   }




 
 if ($g_check==9)
 {
	 //header("Location: qa_mainmenu.php?uid=".$g_uid."&bid=".$g_bid."&docid=".$g_docid);
	 $_SESSION['docid'] = $g_docid;
	  $_SESSION['username'] = $g_uid;
	   $_SESSION['fname'] = $g_bid;
	 header("location:qa_client_login1.php");
	 
 }

else
{
	
	echo "Username/Password not correct.";
}












}






//$conn->close();

//}
?>

<html>
 <form method="POST">
<font size="20" color="blue"><center><a>Client Login Page</a></center></font></br>
	<table>
	
	
		<tr>
				<td>ID</td>
				<td><input style="width:200px" "type="text" id="txt_id" name="txt_id"       /></td>
		
		</tr>
		<tr>
				<td>Password</td>
				<td><input  style="width:200px"       type="password" id="txt_bname" name="txt_bname"      /></td>
		
		</tr>
		
		
		
	
	
		<tr>
				<td><input type="submit"  id="submit" name="submit"   onclick="func_a()"/></td>
		
		</tr>
	
	</table>




</form>

<div id="div_response" style="display:inline">

</div>



</html>