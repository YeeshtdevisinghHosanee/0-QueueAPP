<?php

require_once '../cloudant/cloudant/lib/couch.php';
require_once '../cloudant/cloudant/lib/couchClient.php';
require_once '../cloudant/cloudant/lib/couchDocument.php';

echo "ess";

$login = '0dd9dd5c-3e0b-48f2-97a9-20ce8f4cb2ed-bluemix';
$password = '60c6658e048edd3c52465575a1be76267f40dd8645349556de553e2e82546cb6';
$url = 'https://0dd9dd5c-3e0b-48f2-97a9-20ce8f4cb2ed-bluemix:60c6658e048edd3c52465575a1be76267f40dd8645349556de553e2e82546cb6@0dd9dd5c-3e0b-48f2-97a9-20ce8f4cb2ed-bluemix.cloudantnosqldb.appdomain.cloud';


$user = $login;
$pass =$password;
$db = 'tbl_counter';
echo "ess";

//using couch_document class :
$client = new couchClient ($url,$db);
$doc = new couchDocument($client);
$doc->set( array('_id'=>'yeehos1','name'=>'hosan','firstname'=>'yeesh') ); //create a document and store it in the database
echo $doc->name ; // should echo "Smith"
$doc->name = "Brown"; // set document property "name" to "Brown" and store the updated document in the database



/**

// set a new connector to the CouchDB server
$client = new couchClient ($url,$db);

// document fetching by ID
$doc = $client->getDoc('398de2083ecf063a7938960b517a4eca');
// updating document
$doc->name = array("hello !","world");
try {
   $client->storeDoc($doc);
} catch (Exception $e) {
   echo "Document storage failed : ".$e->getMessage()."<BR>\n";
}


$doc = CouchDocument::getInstance($client,'398de2083ecf063a7938960b517a4eca');
print_r  ($doc->newproperty);
//echo "yes".$doc->name."\n";
echo $doc->type;
**/


?>