<?php
require_once 'qa_connection.php';

$g_uid=$_GET['uid'];
$g_bid=$_GET['bid'];
$g_docid=$_GET['docid'];
echo "User:".$g_uid."   BranchID:".$g_bid;

echo '<font size="2" color="blue" ><p align="right"><a href="qa_mainmenu.php?uid='.$g_uid.'&bid='.$g_bid.'&docid='.$g_docid.'">Back to Main Menu</a></p></font></br>';
echo '<h1>Update, delete and add Serving Information</h1>';

$docid=array();
$column1=array();
$column2=array();
$column3=array();
$column4=array();
$column5=array();
$column6=array();
$column7=array();
$column8=array();
$column9=array();



$crec=0;
$g_check=0;
$db="tbl_counter_criteria";
$client = new couchClient($url,$db);
$all_records = $client->getAllDocs();
 foreach ( $all_records->rows as $row ) {
  
    $doc = CouchDocument::getInstance($client,$row->id);
	
	$user_bid=$doc->_id;
	$bid=$doc->id;
	$co3=$doc->branchid;
	$co4=$doc->bcnum;
	$co5=$doc->maxserved;
	$co6=$doc->start_time;
	$co7=$doc->end_time;
	$co8=$doc->current_time;
	$co9=$doc->counter;
	$co10=$doc->date_created;

		$docid[$crec]=$user_bid;
		$column1[$crec]=$bid;
		$column2[$crec]=$co3;
		$column3[$crec]=$co4;
		$column4[$crec]=$co5;
		$column5[$crec]=$co6;
		$column6[$crec]=$co7;
		$column7[$crec]=$co8;
		$column8[$crec]=$co9;
		$column9[$crec]=$co10;
	
		
		$crec=$crec+1;
	
   }




echo '</br></br></br></br>';
echo '<form action="qa_admin_criteria1.php?uid='.$g_uid.'&bid='.$g_bid.'&docid='.$g_docid.'" method="post">';
echo '<table>';
echo '<tr>';
echo '<td>';
echo '<table border="1"';


echo '<th><td>Docid</td><td>Entry ID</td><td>branchid</td><td>Database CounterID</td><td>Serving Time(in Minutes)</td><td>Starting-Time</td><td>Ending-Time</td><td>Current Time</td><td>Branch counter Number</td><td>Date Created</td><td>Update</td><td>Delete</td></th>';
for ($x = 0; $x < $crec; $x++) {
    //echo "The number is: $x <br>";
	
	
	echo '<tr>';
	echo '<td>'.'<input type="text"  style="width:50px"  name="doc_'.$x.'-'.$docid[$x].'" id="doc_'.$x.'-'.$docid[$x].'" value="'.$docid[$x].'" </td>';
	echo '<td>'.'<input type="text" style="width:50px"  disabled name="col1_'.$x.'-'.$column1[$x].'-'.$column1[$x].'" id="col1_'.$x.'" value="'.$column1[$x].'" </td>';
	echo '<td>'.'<input type="text" style="width:50px"  name="col2_'.$x.'-'.$column1[$x].'" id="col2_'.$x.'-'.$column1[$x].'" value="'.$column2[$x].'" </td>';
	echo '<td>'.'<input type="text" style="width:50px"  name="col3_'.$x.'-'.$column1[$x].'" id="col3_'.$x.'-'.$column1[$x].'" value="'.$column3[$x].'" </td>';
	echo '<td>'.'<input type="text"   style="width:50px" name="col4_'.$x.'-'.$column1[$x].'" id="col4_'.$x.'-'.$column1[$x].'" value="'.$column4[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col5_'.$x.'-'.$column1[$x].'" id="col5_'.$x.'-'.$column1[$x].'" value="'.$column5[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col6_'.$x.'-'.$column1[$x].'" id="col6_'.$x.'-'.$column1[$x].'" value="'.$column6[$x].'" </td>';
	echo '<td>'.'<input type="text" disabled name="col7_'.$x.'-'.$column1[$x].'" id="col7_'.$x.'-'.$column1[$x].'" value="'.$column7[$x].'" </td>';
		echo '<td>'.'<input type="text" style="width:50px"   name="col8_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column8[$x].'" </td>';
		echo '<td>'.'<input type="text" disabled name="col9_'.$x.'-'.$column1[$x].'" id="col9_'.$x.'-'.$column1[$x].'" value="'.$column9[$x].'" </td>';
	
	
	
	echo '<td>'.'<input type="submit" name="clicked['.$x.'-'.$column1[$x].'-'.$docid[$x].']" id="butu_'.$x.'-'.$column1[$x].'" value="'.'update'.'" </td>';
	echo '<td>'.'<input type="submit" name="clicked1['.$x.'-'.$docid[$x].']" id="butd_'.$x.'-'.$docid[$x].'" value="'.'Delete'.'" </td>';
	echo '</tr>';
}



echo '</table>';
echo '</td>';
echo '<td>';
echo '<table border="1"';
//echo '<th><td>Counter ID</td><td>First Name</td><td>Last Name</td><td>add</td></th>';
echo '<th><td>Docid</td><td>Entry ID</td><td>branchid</td><td>Database CounterID</td><td>Serving Time(in Minutes)</td><td>Starting-Time</td><td>Ending-Time</td><td>Current Time</td><td>Branch counter Number</td><td>Date Created</td><td>Add</td></th>';

for ($x1 = 0; $x1 < 1; $x1++) {
    //echo "The number is: $x1 <br>";
	
	
	echo '<tr>';
	echo '<td>'.'<input  style="width:50px" type="text"  disabled name="add1_'.$x1.'" id="add1_'.$x1.'" value="auto" </td>';
	echo '<td>'.'<input  style="width:50px" type="text"  disabled name="add2_'.$x1.'" id="add2_'.$x1.'" value="auto" </td>';
	//echo '<td>'.'<input style="width:50px" type="text"  name="add1_'.$x1.'" id="add1_'.$x1.'" value="" </td>';
	
	
	echo '<td><select size="1" style="width:400px" width="10" name="add3_'.$x1.'" id="add3_'.$x1.'">';
			
				
				$db3="tbl_branch";
				
				$client3 = new couchClient($url,$db3);
				
				$all_records3 = $client3->getAllDocs();
				//echo '<select size="1" style="width:50px" width="10" name="txt_bname" id="txt_bname">';
				
				 foreach ( $all_records3->rows as $row3 ) {
				   
					$doc = CouchDocument::getInstance($client3,$row3->id);
					print_r ($doc);
					$user_bid=$doc->_id;
					$user_branchname=$doc->branchname;
					$user_businessid=$doc->businessid;
					//echo "<br/>".$user_bid;
					//echo "<br/>".$user_branchname;
					//echo "<br/>".$user_businessid;
				
				
				echo '<option  value="'.$user_bid.'">'.$user_bid.'-'.$user_branchname.'</option>';
				 }
				//echo '</select>';
			
		echo	'</select></td>';
	
	
	
	
	
	
	
	
	
	
	//echo '<td>'.'<input style="width:50px" type="text"  name="add4_'.$x1.'" id="add4_'.$x1.'" value="" </td>';
	
	
	
	echo '<td><select size="1" style="width:400px" width="10" name="add4_'.$x1.'" id="add4_'.$x1.'">';
			
				
				$db3="tbl_counter";
				
				$client3 = new couchClient($url,$db3);
				
				$all_records3 = $client3->getAllDocs();
				//echo '<select size="1" style="width:50px" width="10" name="txt_bname" id="txt_bname">';
				
				 foreach ( $all_records3->rows as $row3 ) {
				   
					$doc = CouchDocument::getInstance($client3,$row3->id);
	
					$user_bid=$doc->_id;
					$bid=$doc->id;
					$user_branchname=$doc->fname;
					$user_businessid=$doc->lname;

						$docid[$crec]=$user_bid;
						$column1[$crec]=$bid;
						$column2[$crec]=$user_branchname; //firstname
						$column3[$crec]=$user_businessid; //lastname
						
						$crec=$crec+1;
								
				
				echo '<option  value="'.$user_bid.'">'.$user_bid.'-'.$user_branchname.' '.$user_businessid.'</option>';
				 }
				//echo '</select>';
			
		echo	'</select></td>';
	
	
	
	
	
	
	//echo '<td>'.'<input style="width:50px" type="text"  name="add1_'.$x1.'" id="add1_'.$x1.'" value="" </td>';
	
	
	
			echo '	<td><select name="add5_'.$x1.'" id="add5_'.$x1.'">';
			echo '	  <option value="5">5</option>';
			echo '	  <option value="10">10</option>';
			echo '	  <option value="15">15</option>';
			echo '	  <option value="20">20</option>';
			echo '	   <option value="30">30</option>';
			echo '	    <option value="45">45</option>';
			echo '		 <option value="60">60</option>';
			echo '	</select></td>';
	
	
	
	
	
	
	
	
	echo '<td>'.'<input type="datetime-local"  name="add6_'.$x1.'" id="add6_'.$x1.'" value="" </td>';
	echo '<td>'.'<input type="datetime-local"  name="add7_'.$x1.'" id="add6_'.$x1.'" value="" </td>';
	echo '<td>'.'<input type="text" disabled name="add8_'.$x1.'" id="add8_'.$x1.'" value="" </td>';
	
	
	//echo '<td>'.'<input style="width:50px" type="text"  name="add1_'.$x1.'" id="add1_'.$x1.'" value="" </td>';
	
	echo '<td><select id="txt_counter" name="add9_'.$x1.'" id="add9_'.$x1.'">';
		echo '		  <option value="1">1</option>';
			echo '	  <option value="2">2</option>';
			echo '	  <option value="3">3</option>';
			echo '	  <option value="4">4</option>';
			echo '	   <option value="5">5</option>';
			echo '	    <option value="6">6</option>';
			echo '		 <option value="7">7</option>';
			echo '		  <option value="8">10</option>';
			echo '		  <option value="9">11</option>';
			echo '		  <option value="10">12</option>';
			echo '	</select></td>';
		
	
	
	
	
	
	
	
	echo '<td>'.'<input type="text"   disabled name="add10_'.$x1.'" id="add10_'.$x1.'" value="" </td>';
	
	
	echo '<td>'.'<input type="submit" name="clicked2['.$x1.']" id="butu_'.$x1.'" value="'.'Add'.'" </td>';

	echo '</tr>';
}

echo '</table>';
echo '</td>';
echo '</tr>';
echo '</table>';
echo '</form>';

//http://localhost/queueapp/testapp/qa_admin_branch.php














?>


<head>
<title>Test this</title>
</head>
<body>



</body>
</html>