<?php

require_once './cloudant/cloudant/lib/couch.php';
require_once './cloudant/cloudant/lib/couchClient.php';
require_once './cloudant/cloudant/lib/couchDocument.php';

ini_set('max_execution_time', 300); //300 seconds = 5 minutes
set_time_limit(300);
date_default_timezone_set('Asia/Dubai');

$login = 'xxx';
$password = 'yyy';
$url = 'zzz';


$user = $login;
$pass =$password;


?>