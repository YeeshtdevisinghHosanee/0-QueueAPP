<?php

require_once './lib/couch.php';
require_once './lib/couchClient.php';
require_once './lib/couchDocument.php';

echo "ess";

$login = 'f51f9558-9866-48e0-8199-21cbb2dbb20f-bluemix';
$password = '9db89c84110fcee12a8c1b611a2e668c91528988acf72a8558650f2dd1e49268';
$url = 'https://f51f9558-9866-48e0-8199-21cbb2dbb20f-bluemix:9db89c84110fcee12a8c1b611a2e668c91528988acf72a8558650f2dd1e49268@f51f9558-9866-48e0-8199-21cbb2dbb20f-bluemix.cloudantnosqldb.appdomain.cloud';


$user = $login;
$pass =$password;
$db = 'db_covid';
echo "ess";


// set a new connector to the CouchDB server
$client = new couchClient ($url,$db);

// document fetching by ID
$doc = $client->getDoc('398de2083ecf063a7938960b517a4eca');
// updating document
$doc->name = array("hello !","world");
try {
   $client->storeDoc($doc);
} catch (Exception $e) {
   echo "Document storage failed : ".$e->getMessage()."<BR>\n";
}


$doc = CouchDocument::getInstance($client,'398de2083ecf063a7938960b517a4eca');
print_r  ($doc->newproperty);
//echo "yes".$doc->name."\n";
echo $doc->type;

/**
//using couch_document class :
$doc = new couchDocument($client);
$doc->set( array('_id'=>'JohnSmit8','name'=>'Smith','firstname'=>'John') ); //create a document and store it in the database
echo $doc->name ; // should echo "Smith"
$doc->name = "Brown"; // set document property "name" to "Brown" and store the updated document in the database
**/
?>