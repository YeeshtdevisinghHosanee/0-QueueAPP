<?PHP


$config["couch_dsn"] = "http://localhost:5984/";
$config["couch_database"] = "my_wonderful_database";

